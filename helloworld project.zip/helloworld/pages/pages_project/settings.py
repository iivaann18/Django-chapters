# pages_project/settings.py
ALLOWED_HOSTS = ['*']